
package medievil;

public class Movimiento extends Thread {
    int posX,posY, numeroMovimientos;
    Tablero tablero;
    public Movimiento(int posX, int posY, int numeroMovimientos){
        this.posX = posX;
        this.posY = posY;
        this.numeroMovimientos = numeroMovimientos;
    }
    
    public void moverArriba(){
        tablero.matrizLabel[tablero.x1][tablero.y1].setIcon(null);
        
    }
    
    
}
