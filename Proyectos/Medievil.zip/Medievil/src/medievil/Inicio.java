package medievil;

import java.awt.Color;
import java.awt.Image;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
/**
 *
 * @author dmonterroso
 */
public class Inicio extends javax.swing.JFrame {

    public ImageIcon mago,princesa,guerrero,mago1,mago2,princesa1,princesa2,guerrero1,guerrero2;
    public int orden1=0,orden2=0;
    public String[] personajes1,personajes2;
    public static ImageIcon[] pj1,pj2;
            
    public Inicio() {
        initComponents();
        //setBounds(10,10,400,300);
        setVisible(true);
        setLocationRelativeTo(null);
        setTitle("Medievil");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        personajes1 = new String[3]; //VECTOR DONDE SE GUARDARAN LOS PERSONAJES DEL JUGADOR 1
        personajes2 = new String[3]; //VECTOR DONDE SE GUARDARAN LOS PERSONAJES DEL JUGADOR 2
        pj1 = new ImageIcon[3];
        pj2 = new ImageIcon[3];
        
        ImageIcon magoTemp = new ImageIcon("src/imagenes/mago.png");
        Image m = magoTemp.getImage();
        mago = new ImageIcon(m.getScaledInstance(50, 70, Image.SCALE_SMOOTH));        
        btMago1.setIcon(mago);
        btMago2.setIcon(mago);
                    
        ImageIcon princesaTemp = new ImageIcon("src/imagenes/princesa.jpg");
        Image p = princesaTemp.getImage();
        princesa = new ImageIcon(p.getScaledInstance(50, 70, Image.SCALE_SMOOTH));
        btPrincesa1.setIcon(princesa);
        btPrincesa2.setIcon(princesa);
        
        ImageIcon guerreroTemp = new ImageIcon("src/imagenes/guerrero.jpg");
        Image g = guerreroTemp.getImage();
        guerrero = new ImageIcon(g.getScaledInstance(50, 70, Image.SCALE_SMOOTH));
        btGuerrero1.setIcon(guerrero);
        btGuerrero2.setIcon(guerrero);
        
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pnFondo = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        btMago1 = new javax.swing.JButton();
        btPrincesa1 = new javax.swing.JButton();
        btGuerrero1 = new javax.swing.JButton();
        btMago2 = new javax.swing.JButton();
        btPrincesa2 = new javax.swing.JButton();
        btGuerrero2 = new javax.swing.JButton();
        pnPersonajes1 = new javax.swing.JPanel();
        lbP1_1 = new javax.swing.JLabel();
        lbP1_2 = new javax.swing.JLabel();
        lbP1_3 = new javax.swing.JLabel();
        pnPersonajes2 = new javax.swing.JPanel();
        lbP2_1 = new javax.swing.JLabel();
        lbP2_2 = new javax.swing.JLabel();
        lbP2_3 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        txtJugador2 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtJugador1 = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        btSalir = new javax.swing.JButton();
        btJugar = new javax.swing.JButton();
        btHistorial = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Medievil");
        setPreferredSize(new java.awt.Dimension(700, 500));
        setResizable(false);
        setSize(new java.awt.Dimension(700, 500));

        btMago1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btMago1ActionPerformed(evt);
            }
        });

        btPrincesa1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btPrincesa1ActionPerformed(evt);
            }
        });

        btGuerrero1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btGuerrero1ActionPerformed(evt);
            }
        });

        btMago2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btMago2ActionPerformed(evt);
            }
        });

        btPrincesa2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btPrincesa2ActionPerformed(evt);
            }
        });

        btGuerrero2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btGuerrero2ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btMago1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(35, 35, 35)
                .addComponent(btPrincesa1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(40, 40, 40)
                .addComponent(btGuerrero1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 110, Short.MAX_VALUE)
                .addComponent(btMago2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42)
                .addComponent(btPrincesa2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(37, 37, 37)
                .addComponent(btGuerrero2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(btGuerrero2, javax.swing.GroupLayout.DEFAULT_SIZE, 69, Short.MAX_VALUE)
                    .addComponent(btPrincesa2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 69, Short.MAX_VALUE)
                    .addComponent(btMago2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btMago1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btPrincesa1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btGuerrero1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(20, Short.MAX_VALUE))
        );

        lbP1_1.setBorder(BorderFactory.createLineBorder(new Color(0,0,0)));

        lbP1_2.setBorder(BorderFactory.createLineBorder(new Color(0,0,0)));

        lbP1_3.setBorder(BorderFactory.createLineBorder(new Color(0,0,0)));

        javax.swing.GroupLayout pnPersonajes1Layout = new javax.swing.GroupLayout(pnPersonajes1);
        pnPersonajes1.setLayout(pnPersonajes1Layout);
        pnPersonajes1Layout.setHorizontalGroup(
            pnPersonajes1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnPersonajes1Layout.createSequentialGroup()
                .addGap(26, 26, 26)
                .addComponent(lbP1_1, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(lbP1_2, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(31, 31, 31)
                .addComponent(lbP1_3, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(32, Short.MAX_VALUE))
        );
        pnPersonajes1Layout.setVerticalGroup(
            pnPersonajes1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnPersonajes1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(pnPersonajes1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lbP1_1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbP1_2, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbP1_3, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        lbP2_1.setBorder(BorderFactory.createLineBorder(new Color(0,0,0)));

        lbP2_2.setBorder(BorderFactory.createLineBorder(new Color(0,0,0)));

        lbP2_3.setBorder(BorderFactory.createLineBorder(new Color(0,0,0)));

        javax.swing.GroupLayout pnPersonajes2Layout = new javax.swing.GroupLayout(pnPersonajes2);
        pnPersonajes2.setLayout(pnPersonajes2Layout);
        pnPersonajes2Layout.setHorizontalGroup(
            pnPersonajes2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnPersonajes2Layout.createSequentialGroup()
                .addContainerGap(40, Short.MAX_VALUE)
                .addComponent(lbP2_1, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addComponent(lbP2_2, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42)
                .addComponent(lbP2_3, javax.swing.GroupLayout.PREFERRED_SIZE, 45, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        pnPersonajes2Layout.setVerticalGroup(
            pnPersonajes2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnPersonajes2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnPersonajes2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(lbP2_1, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
                    .addComponent(lbP2_2, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
                    .addComponent(lbP2_3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        jLabel2.setText("Jugador 2");

        jLabel1.setText("Jugador 1");

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addComponent(txtJugador1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 162, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addGap(18, 18, 18)
                .addComponent(txtJugador2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(73, 73, 73))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtJugador2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(txtJugador1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1))
                .addContainerGap(27, Short.MAX_VALUE))
        );

        btSalir.setText("Salir");
        btSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btSalirActionPerformed(evt);
            }
        });

        btJugar.setText("Jugar");
        btJugar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btJugarActionPerformed(evt);
            }
        });

        btHistorial.setText("Historial");

        javax.swing.GroupLayout pnFondoLayout = new javax.swing.GroupLayout(pnFondo);
        pnFondo.setLayout(pnFondoLayout);
        pnFondoLayout.setHorizontalGroup(
            pnFondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnFondoLayout.createSequentialGroup()
                .addGap(107, 107, 107)
                .addComponent(btSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(68, 68, 68)
                .addComponent(btJugar, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(58, 58, 58)
                .addComponent(btHistorial, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnFondoLayout.createSequentialGroup()
                .addContainerGap(20, Short.MAX_VALUE)
                .addGroup(pnFondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnFondoLayout.createSequentialGroup()
                        .addGroup(pnFondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jPanel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(35, 35, 35))
                    .addGroup(pnFondoLayout.createSequentialGroup()
                        .addComponent(pnPersonajes1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(pnPersonajes2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(54, 54, 54))))
        );
        pnFondoLayout.setVerticalGroup(
            pnFondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnFondoLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addGroup(pnFondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pnPersonajes1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(pnPersonajes2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
                .addGroup(pnFondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btSalir)
                    .addComponent(btJugar)
                    .addComponent(btHistorial))
                .addGap(65, 65, 65))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnFondo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(35, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(pnFondo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(34, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btMago1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btMago1ActionPerformed
        // TODO add your handling code here:
        ImageIcon magoTemp = new ImageIcon("src/imagenes/mago1.jpg");
        Image m = magoTemp.getImage();
        mago1 = new ImageIcon(m.getScaledInstance(45, 60, Image.SCALE_SMOOTH));
        orden1++;
        switch (orden1){
            case 1: lbP1_1.setIcon(mago1); pj1[0]=mago1; personajes1[0]="Mago"; break;
            case 2: lbP1_2.setIcon(mago1); pj1[1]=mago1; personajes1[1]="Mago"; break;
            case 3: lbP1_3.setIcon(mago1); pj1[2]=mago1; personajes1[2]="Mago"; break;
        }  
        btMago1.setEnabled(false);
    }//GEN-LAST:event_btMago1ActionPerformed

    private void btSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btSalirActionPerformed
        System.exit(0);
    }//GEN-LAST:event_btSalirActionPerformed

    private void btPrincesa1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btPrincesa1ActionPerformed
        // TODO add your handling code here:
        ImageIcon princesaTemp = new ImageIcon("src/imagenes/princesa1.jpg");
        Image p = princesaTemp.getImage();
        princesa1 = new ImageIcon(p.getScaledInstance(45, 60, Image.SCALE_SMOOTH));
        orden1++;
        switch (orden1){
            case 1: lbP1_1.setIcon(princesa1); pj1[0]=princesa1; personajes1[0]="Princesa"; break;
            case 2: lbP1_2.setIcon(princesa1); pj1[1]=princesa1;  personajes1[1]="Princesa"; break;
            case 3: lbP1_3.setIcon(princesa1); pj1[2]=princesa1; personajes1[2]="Princesa"; break;
        }
        btPrincesa1.setEnabled(false);
    }//GEN-LAST:event_btPrincesa1ActionPerformed

    private void btGuerrero1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btGuerrero1ActionPerformed
        // TODO add your handling code here:
        ImageIcon guerreroTemp = new ImageIcon("src/imagenes/guerrero1.jpg");
        Image g = guerreroTemp.getImage();
        guerrero1 = new ImageIcon(g.getScaledInstance(45, 60, Image.SCALE_SMOOTH));
        orden1++;
        switch (orden1){
            case 1: lbP1_1.setIcon(guerrero1); pj1[0]=guerrero1; personajes1[0]="Guerrero"; break;
            case 2: lbP1_2.setIcon(guerrero1); pj1[1]=guerrero1;  personajes1[1]="Guerrero"; break;
            case 3: lbP1_3.setIcon(guerrero1); pj1[2]=guerrero1; personajes1[2]="Guerrero"; break;
        }
        btGuerrero1.setEnabled(false);
    }//GEN-LAST:event_btGuerrero1ActionPerformed

    private void btMago2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btMago2ActionPerformed
        // TODO add your handling code here:
        ImageIcon magoTemp = new ImageIcon("src/imagenes/mago2.jpg");
        Image m = magoTemp.getImage();
        mago2 = new ImageIcon(m.getScaledInstance(45, 60, Image.SCALE_SMOOTH));
        orden2++;
        switch (orden2){
            case 1: lbP2_1.setIcon(mago2); pj2[0]=mago2; personajes2[0]="Mago"; break;
            case 2: lbP2_2.setIcon(mago2); pj2[1]=mago2; personajes2[1]="Mago"; break;
            case 3: lbP2_3.setIcon(mago2); pj2[2]=mago2; personajes2[2]="Mago"; break;
        }  
        btMago2.setEnabled(false);
    }//GEN-LAST:event_btMago2ActionPerformed

    private void btPrincesa2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btPrincesa2ActionPerformed
        // TODO add your handling code here:
        ImageIcon princesaTemp = new ImageIcon("src/imagenes/princesa2.jpg");
        Image p = princesaTemp.getImage();
        princesa2 = new ImageIcon(p.getScaledInstance(45, 60, Image.SCALE_SMOOTH));
        orden2++;
        switch (orden2){
            case 1: lbP2_1.setIcon(princesa2); pj2[0]=princesa2; personajes2[0]="Princesa"; break;
            case 2: lbP2_2.setIcon(princesa2); pj2[1]=princesa2; personajes2[1]="Princesa"; break;
            case 3: lbP2_3.setIcon(princesa2); pj2[2]=princesa2; personajes2[2]="Princesa"; break;
        }
        btPrincesa2.setEnabled(false);
    }//GEN-LAST:event_btPrincesa2ActionPerformed

    private void btGuerrero2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btGuerrero2ActionPerformed
        // TODO add your handling code here:
        ImageIcon guerreroTemp = new ImageIcon("src/imagenes/guerrero2.jpg");
        Image g = guerreroTemp.getImage();
        guerrero2 = new ImageIcon(g.getScaledInstance(45, 60, Image.SCALE_SMOOTH));
        orden2++;
        switch (orden2){
            case 1: lbP2_1.setIcon(guerrero2); pj2[0]=guerrero2; personajes2[0]="Guerrero"; break;
            case 2: lbP2_2.setIcon(guerrero2); pj2[1]=guerrero2; personajes2[1]="Guerrero"; break;
            case 3: lbP2_3.setIcon(guerrero2); pj2[2]=guerrero2; personajes2[2]="Guerrero"; break;
        }
        btGuerrero2.setEnabled(false);
    }//GEN-LAST:event_btGuerrero2ActionPerformed

    private void btJugarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btJugarActionPerformed
        // TODO add your handling code here:
        if (orden1==3 && orden2==3) {
            int tamañoTablero=0;
            do{
                tamañoTablero = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el tamaño del tablero:"));   
            }while(tamañoTablero <8 || tamañoTablero > 18);
            this.setVisible(false); //OCULTANDO VENTANA INICIO
            Tablero tablero = new Tablero(tamañoTablero,txtJugador1.getText(),txtJugador2.getText(),personajes1,personajes2); //LLAMANDO AL CONSTRUCTOR DE LA CLASE TABLERO
            tablero.setVisible(true); //ABRIENDO VENTANA TABLERO
            
        }
        else{
            JOptionPane.showMessageDialog(null, "Aun faltan personajes por seleccionar", "Mensaje", 2);
        }
    }//GEN-LAST:event_btJugarActionPerformed

    public static void main(String args[]) {
        Inicio inicio = new Inicio();
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btGuerrero1;
    private javax.swing.JButton btGuerrero2;
    private javax.swing.JButton btHistorial;
    private javax.swing.JButton btJugar;
    private javax.swing.JButton btMago1;
    private javax.swing.JButton btMago2;
    private javax.swing.JButton btPrincesa1;
    private javax.swing.JButton btPrincesa2;
    private javax.swing.JButton btSalir;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lbP1_1;
    private javax.swing.JLabel lbP1_2;
    private javax.swing.JLabel lbP1_3;
    private javax.swing.JLabel lbP2_1;
    private javax.swing.JLabel lbP2_2;
    private javax.swing.JLabel lbP2_3;
    private javax.swing.JPanel pnFondo;
    private javax.swing.JPanel pnPersonajes1;
    private javax.swing.JPanel pnPersonajes2;
    private javax.swing.JTextField txtJugador1;
    private javax.swing.JTextField txtJugador2;
    // End of variables declaration//GEN-END:variables
}
