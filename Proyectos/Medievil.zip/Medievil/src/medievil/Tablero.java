package medievil;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Random;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.Timer;

/**
 *
 * @author dmonterroso
 */
public class Tablero extends javax.swing.JFrame {
    
    public ImageIcon vidas1,vidas2;
    public int tamañoTablero;
    public int tamañoBloque;
    public int [][] matrizLogica;
    //public int [][] matrizLogicaVidas1, matrizLogicaVidas2;
    public JLabel [][] matrizLabel;
    public JLabel [][] matrizLabelVidas1, matrizLabelVidas2;
    public int contVidas1,contVidas2;
    private Timer tiempo;
    private int minutos,segundos;
    public int x1,y1,x2,y2;
    
    private ActionListener cronometro = new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                segundos++;
                if(segundos==60){
                    segundos=0;
                    minutos++;
                }
                if(minutos==1){
                    segundos=0;
                    minutos=0;
                    tiempo.stop();
                }
                actualizarLabel();
            }
    };
    private void actualizarLabel(){
        String tiempo = (minutos<=9?"0":"")+minutos+":"+(segundos<=9?"0":"")+segundos;
        lbTiempo.setText(tiempo);
    }
    
    
    private void actualizarDado(String imagenDado){
        ImageIcon dadoTemp = new ImageIcon("src/imagenes/"+imagenDado);
        Image d = dadoTemp.getImage();
        ImageIcon dado = new ImageIcon(d.getScaledInstance(75, 75, Image.SCALE_SMOOTH));
        btDado.setIcon(dado);
        btDado.setOpaque(false);
        btDado.setContentAreaFilled(false);
    }
    
    public Tablero(int tamTablero,String jugador1, String jugador2, String personajes1[], String personajes2[]) {
        initComponents();
        setLocationRelativeTo(null);
        setTitle("Medievil");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        //jLabel1.setEnabled(false);
        tiempo = new Timer(1000,cronometro);
        tiempo.start();
        
        btJugador1.setText(jugador1);
        lbPersonaje11.setText(personajes1[0]);
        lbPersonaje12.setText(personajes1[1]);
        lbPersonaje13.setText(personajes1[2]);
        btJugador2.setText(jugador2);
        lbPersonaje21.setText(personajes2[0]);
        lbPersonaje22.setText(personajes2[1]);
        lbPersonaje23.setText(personajes2[2]);
        
                        
        this.tamañoTablero = tamTablero;
        ubicarPersonajes();
        llenarTablero(tamañoTablero);
        llenarVidas1();
        llenarVidas2();
        crearItems();
        
        imagenBotones("up-blue.png",btMoverArriba);
        imagenBotones("down-blue.png",btMoverAbajo);
        imagenBotones("left-blue.png",btMoverIzquierda);
        imagenBotones("right-blue.png",btMoverDerecha);
        imagenBotones("up-grey.png",btAtacarArriba);
        imagenBotones("down-grey.png",btAtacarAbajo);
        imagenBotones("left-grey.png",btAtacarIzquierda);
        imagenBotones("right-grey.png",btAtacarDerecha);
        imagenBotones("clock.png",btTiempoTitulo);
        btTiempoTitulo.setOpaque(false);
        btTiempoTitulo.setContentAreaFilled(false);
        
    }

    public void crearItems (){
        int corazones = (int)(tamañoTablero*tamañoTablero*0.05);
        for (int i = 0; i < corazones; i++) {
            Random item1 = new Random();
            int x = item1.nextInt((tamañoTablero-1));
            int y = item1.nextInt((tamañoTablero-1));
            while(matrizLabel[y][x].getIcon()!=null){ //DIFERENTE DE NULL (SI TIENE ALGO)
                x = item1.nextInt((tamañoTablero-1));
                y = item1.nextInt((tamañoTablero-1));
            }
            ImageIcon corazonTemp = new ImageIcon("src/imagenes/heart_full.png");
            Image c = corazonTemp.getImage();
            ImageIcon corazon = new ImageIcon(c.getScaledInstance(tamañoBloque, tamañoBloque, Image.SCALE_SMOOTH));
            matrizLabel[y][x].setIcon(corazon); 
            System.out.println("corazon " + x + " - " + y);
        }
        
        int bombas = (int)(tamañoTablero*tamañoTablero*0.10);
        for (int j = 0; j < bombas; j++) {
            Random item2 = new Random();
            int x = item2.nextInt((tamañoTablero-1));
            int y = item2.nextInt((tamañoTablero-1));
            while(matrizLabel[y][x].getIcon()!=null){
                x = item2.nextInt((tamañoTablero-1));
                y = item2.nextInt((tamañoTablero-1));
            }
            ImageIcon bombasTemp = new ImageIcon("src/imagenes/grenade.png");
            Image b = bombasTemp.getImage();
            ImageIcon bomba = new ImageIcon(b.getScaledInstance(tamañoBloque, tamañoBloque, Image.SCALE_SMOOTH));
            matrizLabel[y][x].setIcon(bomba); 
            System.out.println("bomba " + x + " - " + y);            
        }
        pnTablero.repaint();
    }
    
    public void llenarTablero(int tamañoTablero){
        tamañoBloque = 500/tamañoTablero; //CALCULANDO EL TAMAÑO DE CADA BLOQUE
        matrizLogica = new int[tamañoTablero][tamañoTablero]; //DANDO TAMAÑO A LA MATRIZ LOGICA
        matrizLabel = new JLabel[tamañoTablero][tamañoTablero]; //DANDO TAMAÑO A LA MATRIZ LABEL
        
        for (int i = 0; i < tamañoTablero; i++) { //RECORRIENDO FILAS
            for (int j = 0; j < tamañoTablero; j++) { //RECORRIENDO COLUMNAS
                matrizLogica[i][j] = 0; //LLENANDO DE 0 LA MATRIZ LOGICA
                //matrizLabel[i][j].setIcon(null);
            }
        }
        repintarTablero(); //PINTANDO EL TABLERO
    }
    
    public void repintarTablero(){
        for (int i = 0; i < tamañoTablero; i++) {
            for (int j = 0; j < tamañoTablero; j++) {
                JLabel casilla;
                //if(matrizLogica[i][j]==0){
                    casilla = new JLabel();
                    casilla.setOpaque(false);
                    casilla.setBorder(BorderFactory.createLineBorder(new Color(0,0,0)));
                    casilla.setBounds(i*tamañoBloque, j*tamañoBloque, tamañoBloque, tamañoBloque);
                    matrizLabel[i][j] = casilla;
                    pnTablero.add(matrizLabel[i][j],BorderLayout.CENTER);
                    pnTablero.repaint();
                    
                //}
            }
        }
        matrizLabel[y1][x1].setIcon(Inicio.pj1[0]);
        matrizLabel[y2][x2].setIcon(Inicio.pj2[0]);
        pnTablero.repaint();
    }
    
    public void ubicarPersonajes(){
        Random aleatorio1 = new Random();
        this.x1 = aleatorio1.nextInt(tamañoTablero-1);
        this.y1 = aleatorio1.nextInt(tamañoTablero-1);
                
        Random aleatorio2 = new Random();
        this.x2 = aleatorio2.nextInt(tamañoTablero-1);
        this.y2 = aleatorio2.nextInt(tamañoTablero-1);
                
        System.out.println("pj1 "+x1+" - "+y1+ " ; pj2 "+x2+" - "+y2);
        pnTablero.repaint();
    }
    
    public int getUbicacion(){
        return x1;
    }
    
    public void llenarVidas1(){
        //matrizLogicaVidas1 = new int [4][4];
        matrizLabelVidas1 = new JLabel[4][4];
        for (int i = 0; i < 5; i++) {
            //for (int j = 0; j < 4; j++) {
            contVidas1++;  
            //}
        }
        ImageIcon vidas1Temp = new ImageIcon("src/imagenes/heart_full.png");
        Image v = vidas1Temp.getImage();
        vidas1 = new ImageIcon(v.getScaledInstance(25, 25, Image.SCALE_SMOOTH));
        
        repintarVidas1();
    }
    public void repintarVidas1(){
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                JLabel casilla;
                if(contVidas1 > 0){
                    casilla = new JLabel(vidas1); //Asignando imagen al Label casilla
                    casilla.setOpaque(false);
                    casilla.setBounds(j*25,i*25,25,25);
                    matrizLabelVidas1[i][j] = casilla;
                    casilla.setToolTipText(i+" " +j);
                    pnVidas1.add(matrizLabelVidas1[i][j]);
                    pnVidas1.repaint();
                    contVidas1 --;
                }
            }
        }
    }
    
    public void llenarVidas2(){
        matrizLabelVidas2 = new JLabel[4][4];
        for (int i = 0; i < 5; i++) {
            contVidas2++;
        }
        ImageIcon vidas2Temp = new ImageIcon("src/imagenes/heart_full.png"); //ASIGNANDO LA RUTA DE LA IMAGEN
        Image v = vidas2Temp.getImage(); //ASIGNANDO IMAGEN A LA VARIABLE DE TIPO IMAGEN
        vidas2 = new ImageIcon(v.getScaledInstance(25, 25, Image.SCALE_SMOOTH)); //INSTANCIANDO Y DANDO TAMAÑO A LA IMAGEN
        repintarVidas2(); //LLAMANDO AL METODO REPINTAR
    }
    public void repintarVidas2(){ //PINTANDO EL TABLERO DONDE SE MOSTRARAN VIDAS DEL JUGADOR 2
        for (int i = 0; i < 4; i++) { //RECORRIENDO FILAS
            for (int j = 0; j < 4; j++) { //RECORRIENDO COLUMNAS
                JLabel casilla; //VARIABLE DE TIPO LABEL
                if(contVidas2 > 0){ //CONDICIONAL
                    casilla = new JLabel(vidas2); //INSTANCIANDO Y ASIGNANDO IMAGEN AL LABEL
                    casilla.setOpaque(false);
                    //casilla.setBounds(j, i, WIDTH, HEIGHT); //COORDENANDA EN X(j), COORDENADA EN Y(i)
                    casilla.setBounds(j*25,i*25,25,25); 
                    matrizLabelVidas2[i][j] = casilla; //COLOCANDO LA VARIABLE CASILLA A CASA UNA DE LAS POSICIONES DE LA MATRIZ
                    pnVidas2.add(matrizLabelVidas2[i][j],BorderLayout.CENTER); //AGREGANDO LA MATRIZ DE LABEL AL PANEL
                    pnVidas2.repaint();
                    contVidas2--;
                }
            }
        }
    }
    
    public void imagenBotones (String nombreImagen, JButton boton){
        ImageIcon imagenTemp  = new ImageIcon("src/imagenes/"+nombreImagen);
        Image i = imagenTemp.getImage();
        ImageIcon imagen = new ImageIcon(i.getScaledInstance(33, 33, Image.SCALE_SMOOTH));
        boton.setIcon(imagen);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lbTiempo = new javax.swing.JLabel();
        pnDatos = new javax.swing.JPanel();
        btJugador1 = new javax.swing.JButton();
        btJugador2 = new javax.swing.JButton();
        pnVidas1 = new javax.swing.JPanel();
        pnVidas2 = new javax.swing.JPanel();
        lbPersonaje11 = new javax.swing.JLabel();
        lbPersonaje12 = new javax.swing.JLabel();
        lbPersonaje13 = new javax.swing.JLabel();
        lbPersonaje21 = new javax.swing.JLabel();
        lbPersonaje22 = new javax.swing.JLabel();
        lbPersonaje23 = new javax.swing.JLabel();
        pnAcciones = new javax.swing.JPanel();
        btDado = new javax.swing.JButton();
        btMoverArriba = new javax.swing.JButton();
        btMoverAbajo = new javax.swing.JButton();
        btMoverIzquierda = new javax.swing.JButton();
        btMoverDerecha = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();
        btAtacarDerecha = new javax.swing.JButton();
        btAtacarAbajo = new javax.swing.JButton();
        btAtacarArriba = new javax.swing.JButton();
        btOmitirAtaque = new javax.swing.JButton();
        btAtacarIzquierda = new javax.swing.JButton();
        btTiempoTitulo = new javax.swing.JButton();
        pnTablero = new javax.swing.JPanel();
        btSalir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        jPanel1.setPreferredSize(new java.awt.Dimension(300, 551));

        lbTiempo.setText("00:00");

        btJugador1.setText("Jugador 1");

        btJugador2.setText("Jugador 2");

        pnVidas1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        pnVidas1.setPreferredSize(new java.awt.Dimension(100, 100));

        javax.swing.GroupLayout pnVidas1Layout = new javax.swing.GroupLayout(pnVidas1);
        pnVidas1.setLayout(pnVidas1Layout);
        pnVidas1Layout.setHorizontalGroup(
            pnVidas1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 0, Short.MAX_VALUE)
        );
        pnVidas1Layout.setVerticalGroup(
            pnVidas1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 98, Short.MAX_VALUE)
        );

        pnVidas2.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        pnVidas2.setPreferredSize(new java.awt.Dimension(100, 100));

        javax.swing.GroupLayout pnVidas2Layout = new javax.swing.GroupLayout(pnVidas2);
        pnVidas2.setLayout(pnVidas2Layout);
        pnVidas2Layout.setHorizontalGroup(
            pnVidas2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 98, Short.MAX_VALUE)
        );
        pnVidas2Layout.setVerticalGroup(
            pnVidas2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 98, Short.MAX_VALUE)
        );

        lbPersonaje11.setText("Personaje 1");

        lbPersonaje12.setText("Personaje 2");

        lbPersonaje13.setText("Personaje 3");

        lbPersonaje21.setText("Personaje 1");

        lbPersonaje22.setText("Personaje 2");

        lbPersonaje23.setText("Personaje 3");

        javax.swing.GroupLayout pnDatosLayout = new javax.swing.GroupLayout(pnDatos);
        pnDatos.setLayout(pnDatosLayout);
        pnDatosLayout.setHorizontalGroup(
            pnDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnDatosLayout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(pnDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(btJugador2)
                        .addComponent(btJugador1))
                    .addComponent(lbPersonaje11)
                    .addComponent(lbPersonaje12)
                    .addComponent(lbPersonaje13)
                    .addComponent(lbPersonaje21)
                    .addComponent(lbPersonaje22)
                    .addComponent(lbPersonaje23))
                .addGap(18, 18, 18)
                .addGroup(pnDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(pnVidas2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pnVidas1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pnDatosLayout.setVerticalGroup(
            pnDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnDatosLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pnDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pnVidas1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pnDatosLayout.createSequentialGroup()
                        .addComponent(btJugador1)
                        .addGap(5, 5, 5)
                        .addComponent(lbPersonaje11)
                        .addGap(10, 10, 10)
                        .addComponent(lbPersonaje12)
                        .addGap(7, 7, 7)
                        .addComponent(lbPersonaje13)))
                .addGap(18, 18, 18)
                .addGroup(pnDatosLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnDatosLayout.createSequentialGroup()
                        .addComponent(btJugador2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lbPersonaje21)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lbPersonaje22)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lbPersonaje23))
                    .addComponent(pnVidas2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(36, Short.MAX_VALUE))
        );

        btDado.setToolTipText("Tirar");
        btDado.setBorder(null);
        btDado.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        btDado.setPreferredSize(new java.awt.Dimension(75, 75));
        btDado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btDadoActionPerformed(evt);
            }
        });

        btMoverArriba.setPreferredSize(new java.awt.Dimension(33, 33));
        btMoverArriba.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btMoverArribaActionPerformed(evt);
            }
        });

        btMoverAbajo.setPreferredSize(new java.awt.Dimension(33, 33));

        btMoverIzquierda.setPreferredSize(new java.awt.Dimension(33, 33));

        btMoverDerecha.setPreferredSize(new java.awt.Dimension(33, 33));

        jLabel5.setText("Ataque Personaje");

        btAtacarDerecha.setPreferredSize(new java.awt.Dimension(33, 33));
        btAtacarDerecha.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAtacarDerechaActionPerformed(evt);
            }
        });

        btAtacarAbajo.setPreferredSize(new java.awt.Dimension(33, 33));

        btAtacarArriba.setPreferredSize(new java.awt.Dimension(33, 33));

        btOmitirAtaque.setText("Omitir");
        btOmitirAtaque.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));

        btAtacarIzquierda.setPreferredSize(new java.awt.Dimension(33, 33));

        javax.swing.GroupLayout pnAccionesLayout = new javax.swing.GroupLayout(pnAcciones);
        pnAcciones.setLayout(pnAccionesLayout);
        pnAccionesLayout.setHorizontalGroup(
            pnAccionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pnAccionesLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addGap(96, 96, 96))
            .addGroup(pnAccionesLayout.createSequentialGroup()
                .addGroup(pnAccionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnAccionesLayout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(btDado, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(38, 38, 38)
                        .addComponent(btMoverIzquierda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(pnAccionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnAccionesLayout.createSequentialGroup()
                                .addGap(3, 3, 3)
                                .addGroup(pnAccionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btMoverArriba, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btMoverAbajo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(pnAccionesLayout.createSequentialGroup()
                                .addGap(39, 39, 39)
                                .addComponent(btMoverDerecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(pnAccionesLayout.createSequentialGroup()
                        .addGap(54, 54, 54)
                        .addComponent(btAtacarIzquierda, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(pnAccionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pnAccionesLayout.createSequentialGroup()
                                .addGap(36, 36, 36)
                                .addGroup(pnAccionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(btAtacarArriba, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btAtacarAbajo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(pnAccionesLayout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(btOmitirAtaque)
                                .addGap(18, 18, 18)
                                .addComponent(btAtacarDerecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(40, Short.MAX_VALUE))
        );
        pnAccionesLayout.setVerticalGroup(
            pnAccionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnAccionesLayout.createSequentialGroup()
                .addGroup(pnAccionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pnAccionesLayout.createSequentialGroup()
                        .addComponent(btMoverArriba, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(7, 7, 7)
                        .addGroup(pnAccionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btMoverIzquierda, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btMoverDerecha, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(7, 7, 7)
                        .addComponent(btMoverAbajo, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pnAccionesLayout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(btDado, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(38, 38, 38)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btAtacarArriba, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(7, 7, 7)
                .addGroup(pnAccionesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btOmitirAtaque, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btAtacarDerecha, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btAtacarIzquierda, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(7, 7, 7)
                .addComponent(btAtacarAbajo, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        btTiempoTitulo.setBorder(null);
        btTiempoTitulo.setPreferredSize(new java.awt.Dimension(33, 33));

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(93, 93, 93)
                        .addComponent(btTiempoTitulo, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(lbTiempo, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(pnDatos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(pnAcciones, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lbTiempo, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btTiempoTitulo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGap(8, 8, 8)))
                .addComponent(pnDatos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(pnAcciones, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        javax.swing.GroupLayout pnTableroLayout = new javax.swing.GroupLayout(pnTablero);
        pnTablero.setLayout(pnTableroLayout);
        pnTableroLayout.setHorizontalGroup(
            pnTableroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 500, Short.MAX_VALUE)
        );
        pnTableroLayout.setVerticalGroup(
            pnTableroLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 500, Short.MAX_VALUE)
        );

        btSalir.setText("Salir");
        btSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btSalirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(pnTablero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(230, 230, 230)
                        .addComponent(btSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(47, 47, 47)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 305, Short.MAX_VALUE)
                .addGap(21, 21, 21))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(22, 22, 22)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 651, Short.MAX_VALUE)
                .addGap(27, 27, 27))
            .addGroup(layout.createSequentialGroup()
                .addGap(64, 64, 64)
                .addComponent(pnTablero, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(btSalir)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btAtacarDerechaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAtacarDerechaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btAtacarDerechaActionPerformed

    private void btSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btSalirActionPerformed
        // TODO add your handling code here:
        //System.exit(0);
        tiempo.stop();
        JOptionPane.showMessageDialog(null, "Boton Salir");
    }//GEN-LAST:event_btSalirActionPerformed

    private void btDadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btDadoActionPerformed
        // TODO add your handling code here:
            String imagenDado="";
            Random dado = new Random();
            //int numero = 1;
            int numeroDado = dado.nextInt(6)+1; //NUMEROS ALEATORIOS ENTRE 1 Y 6 
//            while(temporalNumero == numero){
//                numero = (int)dado.nextDouble()*6+1; //NUMEROS ALEATORIOS ENTRE 1 Y 6     
//            }
            switch(numeroDado){
                case 1:
                    imagenDado="dado1.png"; break;
                case 2:
                    imagenDado="dado2.png"; break;
                case 3:
                    imagenDado="dado3.png"; break;
                case 4:
                    imagenDado="dado4.png"; break;
                case 5:
                    imagenDado="dado5.png"; break;
                case 6:    
                    imagenDado="dado6.png"; break;
            }
            System.out.println("Numero dado " + numeroDado);
            actualizarDado(imagenDado);
    }//GEN-LAST:event_btDadoActionPerformed

    private void btMoverArribaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btMoverArribaActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_btMoverArribaActionPerformed

    public static void main(String args[]) {
        //Tablero tablero = new Tablero(15);
        //tablero.setVisible(true);

        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
            //Tablero tablero = new Tablero().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btAtacarAbajo;
    private javax.swing.JButton btAtacarArriba;
    private javax.swing.JButton btAtacarDerecha;
    private javax.swing.JButton btAtacarIzquierda;
    private javax.swing.JButton btDado;
    private javax.swing.JButton btJugador1;
    private javax.swing.JButton btJugador2;
    private javax.swing.JButton btMoverAbajo;
    private javax.swing.JButton btMoverArriba;
    private javax.swing.JButton btMoverDerecha;
    private javax.swing.JButton btMoverIzquierda;
    private javax.swing.JButton btOmitirAtaque;
    private javax.swing.JButton btSalir;
    private javax.swing.JButton btTiempoTitulo;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JLabel lbPersonaje11;
    private javax.swing.JLabel lbPersonaje12;
    private javax.swing.JLabel lbPersonaje13;
    private javax.swing.JLabel lbPersonaje21;
    private javax.swing.JLabel lbPersonaje22;
    private javax.swing.JLabel lbPersonaje23;
    private javax.swing.JLabel lbTiempo;
    private javax.swing.JPanel pnAcciones;
    private javax.swing.JPanel pnDatos;
    private javax.swing.JPanel pnTablero;
    private javax.swing.JPanel pnVidas1;
    private javax.swing.JPanel pnVidas2;
    // End of variables declaration//GEN-END:variables
}
