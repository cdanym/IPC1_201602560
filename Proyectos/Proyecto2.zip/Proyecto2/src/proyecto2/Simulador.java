package proyecto2;

import java.awt.Desktop;
import java.awt.Image;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

public class Simulador extends javax.swing.JFrame {
    
    public ImageIcon aviones,desabordajes,equipaje,escritorios,estaciones,documentos;
    
    public int cantidadAviones;
    public int cantidadEscritorios;
    public int cantidadEstaciones;
    
    protected int contadorAviones, contadorPasajeros, contadorTurnosEscritorio, contadorTurnosMantenimiento, contadorEquipaje, contadorDocumentos, contador;
    //protected int pasajeros;
    //protected int matelas;
    Lista listaAviones, listaAvionesNombre;
    String path;
    Cola colaDesabordaje;
    Lista listaEquipaje;
    Lista listaEscritorios;
    Lista listaEstaciones;
    Cola colaPasajeros;
    Pila pilaDocumentos;
    
    protected Avion avion;
    protected Pasajero pasajero;
    protected EscritorioRegistro escritorioRegistro;
    protected Mantenimiento estacionesMantenimiento;
    
    public Simulador() {
        initComponents();
        setVisible(true);
        setLocationRelativeTo(null);
        setTitle("Simulador");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        
        //CREANDO LISTAS
        listaAviones = new ListaEnlazadaDoble();
        listaAvionesNombre = new ListaEnlazadaDoble();
        path = "archivoLista.obj";
        //listaAvionesDesabordaje = new ListaEnlazadaDoble();
        //colaDesabordaje = new Cola();
        //listaEquipaje = new ListaCircularDoble();
        listaEscritorios = new ListaEnlazadaDoble();
        //listaEstaciones = new ListaEnlazadaSimple();
        //pilaDocumentos = new Pila();
        
        escritorioRegistro = new EscritorioRegistro();
        
        contadorAviones = 1;
        contadorPasajeros = 1;
        
        System.out.println("---FIN---");
    }
    
    public void inicioAviones(){
        Avion avion;
        for (int i = 1; i <= cantidadAviones; i++) {
            avion = new Avion();
            avion.setNombre("Avion" + i);
            listaAvionesNombre.insertarAlFinal(avion.getNombre()); //LISTA DE AVIONES, GUARDANDO NOMBRE DEL AVION
            System.out.println(listaAvionesNombre.primero.getDato());
            //System.out.println(i);
        }
    }
    
    public void setCantidadAviones(int cantidadAviones) {
        this.cantidadAviones = cantidadAviones;
    }

    public void setCantidadEscritorios(int cantidadEscritorios) {
        this.cantidadEscritorios = cantidadEscritorios;
    }

    public void setCantidadEstaciones(int cantidadEstaciones) {
        this.cantidadEstaciones = cantidadEstaciones;
    }
    
    public int getCantidadAviones(){
        return cantidadAviones;
    }
    
    public int getCantidadEscritorios(){
        return cantidadEscritorios;
    }
    
    public int getCantidadEstaciones(){
        return cantidadEstaciones;
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        txtAreaConsola = new javax.swing.JTextArea();
        btSiguiente = new javax.swing.JButton();
        btAutomatico = new javax.swing.JButton();
        pnFondo = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        lbAviones = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        lbDesabordaje = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        lbEquipaje = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        lbRegistro = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        lbEstaciones = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        lbDocumentos = new javax.swing.JLabel();
        btSalir = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);

        txtAreaConsola.setBackground(new java.awt.Color(0, 0, 0));
        txtAreaConsola.setColumns(20);
        txtAreaConsola.setForeground(new java.awt.Color(255, 255, 255));
        txtAreaConsola.setLineWrap(true);
        txtAreaConsola.setRows(5);
        jScrollPane1.setViewportView(txtAreaConsola);

        btSiguiente.setText("Siguiente");
        btSiguiente.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btSiguienteActionPerformed(evt);
            }
        });

        btAutomatico.setText("Automatico");
        btAutomatico.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btAutomaticoActionPerformed(evt);
            }
        });

        pnFondo.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel1.setText("Llegada de Avion");

        jLabel3.setText("Cola Desabordaje");

        jLabel5.setText("Equipaje");

        jLabel7.setText("Escritorios de registro");

        jLabel9.setText("Estaciones de servicio");

        jLabel11.setText("Documentos");

        javax.swing.GroupLayout pnFondoLayout = new javax.swing.GroupLayout(pnFondo);
        pnFondo.setLayout(pnFondoLayout);
        pnFondoLayout.setHorizontalGroup(
            pnFondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnFondoLayout.createSequentialGroup()
                .addGap(60, 60, 60)
                .addGroup(pnFondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel11)
                    .addComponent(jLabel9)
                    .addComponent(jLabel7)
                    .addComponent(jLabel5)
                    .addComponent(jLabel3)
                    .addComponent(jLabel1)
                    .addComponent(lbDocumentos, javax.swing.GroupLayout.DEFAULT_SIZE, 600, Short.MAX_VALUE)
                    .addComponent(lbEstaciones, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lbRegistro, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lbEquipaje, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lbDesabordaje, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lbAviones, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(160, Short.MAX_VALUE))
        );
        pnFondoLayout.setVerticalGroup(
            pnFondoLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pnFondoLayout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lbAviones, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbDesabordaje, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(26, 26, 26)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lbEquipaje, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbRegistro, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel9)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbEstaciones, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lbDocumentos, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(64, Short.MAX_VALUE))
        );

        btSalir.setLabel("Salir");
        btSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btSalirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(57, 57, 57)
                        .addComponent(btSiguiente)
                        .addGap(28, 28, 28)
                        .addComponent(btAutomatico))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 400, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(171, 171, 171)
                        .addComponent(btSalir, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(pnFondo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(32, 32, 32)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btSiguiente)
                            .addComponent(btAutomatico))
                        .addGap(18, 18, 18)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(37, 37, 37)
                        .addComponent(btSalir))
                    .addComponent(pnFondo, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(19, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btSiguienteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btSiguienteActionPerformed
        // TODO add your handling code here:
        operaciones();
        
    }//GEN-LAST:event_btSiguienteActionPerformed

    public void operaciones(){
        if (contadorAviones <= getCantidadAviones()) {
            llegadaAviones();
            
            //LLENANDO LISTAS
            listaEscritorios();
            listaEstaciones();
            listaEquipajes();
            pilaDocumentos();
            
            imprimirConsola();
            //listaAvionesNombre.graficarListaAviones();
            
            graficarListaAviones();
            graficarColaDesabordaje();
            graficarListaEquipaje();
            graficarListaEscritorios();
            graficarListaEstaciones();
            graficarPilaDocumentos();
        }else{
            JOptionPane.showMessageDialog(null, "Fin de la Simulacion");
            lbAviones.setVisible(false);
            lbDesabordaje.setVisible(false);
            lbDocumentos.setVisible(false);
            lbEquipaje.setVisible(false);
            lbEstaciones.setVisible(false);
            lbRegistro.setVisible(false);
            btAutomatico.setEnabled(false);
            btSiguiente.setEnabled(false);
        }
    }
    
    private void btAutomaticoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btAutomaticoActionPerformed
        // TODO add your handling code here:
        while(contadorAviones <= getCantidadAviones()){
            operaciones();
        }
        JOptionPane.showMessageDialog(null, "Fin de la simulacion");
            lbAviones.setVisible(false);
            lbDesabordaje.setVisible(false);
            lbDocumentos.setVisible(false);
            lbEquipaje.setVisible(false);
            lbEstaciones.setVisible(false);
            lbRegistro.setVisible(false);
            btAutomatico.setEnabled(false);
            btSiguiente.setEnabled(false);
        //System.exit(0);
    }//GEN-LAST:event_btAutomaticoActionPerformed

    private void btSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btSalirActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_btSalirActionPerformed

    public void llegadaAviones(){
        contadorTurnosMantenimiento = 0;
        contadorEquipaje = 0;
        contadorDocumentos = 0;
        contadorTurnosEscritorio = 0;
        //Avion avion;
        //for (int i = 1; i <= cantidadAviones; i++) {
            avion = new Avion();
            
            contadorTurnosMantenimiento = avion.getTurnoMantenimiento();
            
            avion.setNombre("Avion" + contadorAviones + avion.getTipo() );
            listaAviones.insertarAlFinal(avion.getNombre()); //------------GUARDANDO AVIONES EN LA LISTA DOBLE ENLAZADA
            colaDesabordaje = new Cola();
            for (int i = 1; i <= avion.getPasajeros(); i++) {
                pasajero = new Pasajero();
                
                contadorEquipaje = contadorEquipaje + pasajero.getCantidadMaletas();
                contadorDocumentos = contadorDocumentos + pasajero.getCantidadDocumentos();
                contadorTurnosEscritorio = contadorTurnosEscritorio + pasajero.getTurnoRegistro();
                
                pasajero.setNombre("Pasajero" + contadorPasajeros + avion.getNombre());
                colaDesabordaje.encolar(pasajero.getNombre()); //-----------GUARDANDO PASAJEROS EN LA COLA SIMPLE
            }
            System.out.println(listaAviones.getNombre());
            //this.pasajeros = avion.getPasajeros();
            //System.out.println(listaAvionesNombre.ultimo.getDato());
        //}
        contadorAviones++;
    }
    
    public void listaEscritorios (){
        for (int i = 1; i <= getCantidadEscritorios(); i++) {
            escritorioRegistro = new EscritorioRegistro();
            escritorioRegistro.setNombre(i);
            listaEscritorios.insertarAlFinal("Escritorio " + escritorioRegistro.getNombre()); //---------------GUARDANDO LISTA DE ESCRITORIOS
        }
    }
    
    public void listaEstaciones(){
        listaEstaciones = new ListaEnlazadaSimple();
        for (int i = 1; i <= getCantidadEstaciones(); i++) {
            estacionesMantenimiento = new Mantenimiento();
            estacionesMantenimiento.setNombre("Estacion" + i);
            listaEstaciones.insertarAlFinal(estacionesMantenimiento.getNombre());
        }
    }
    
    public void listaEquipajes(){
        listaEquipaje = new ListaCircularDoble();
        for (int i = 1; i <= contadorEquipaje; i++) {
            listaEquipaje.insertarAlFinal("Equipaje " + i);
        }
    }
    
    public void pilaDocumentos(){
        pilaDocumentos = new Pila();
        for (int i = 1; i <= contadorDocumentos; i++) {
            pilaDocumentos.apilar("Documento " + i);
        }
    }
    
    public void imprimirConsola(){
        txtAreaConsola.append("\n" + avion.getNombre() + "\n");
        txtAreaConsola.append("Numero de pasajeros: " + avion.getPasajeros() + "\n");
        txtAreaConsola.append("Turnos de desabordaje: " + avion.getTurnoDesabordaje() + "\n");
        txtAreaConsola.append("Turnos de mantenimiento: " + avion.getTurnoMantenimiento()+ "\n");
        txtAreaConsola.append("---ESCRITORIOS DE REGISTRO---" + "\n");
        for (int i = 1; i <= getCantidadEscritorios(); i++) {
            escritorioRegistro.setNombre(i);
            txtAreaConsola.append("Escritorio " + escritorioRegistro.getNombre() + ": -Disponible" + "\n");
                //colaPasajeros.encolar();
            txtAreaConsola.append("\tPasajero atendido: " + "Ninguno" + "\n");
            txtAreaConsola.append("\tTurnos restantes: " + (contadorTurnosEscritorio/getCantidadEscritorios()) +"\n");
            txtAreaConsola.append("\tCantidad de documentos: " + (contadorDocumentos/getCantidadEscritorios()) + "\n");
        }
        
        txtAreaConsola.append("---ESTACIONES DE SERVICIO---" + "\n");
        txtAreaConsola.append("Estacion " + 1 +"\n");            
        txtAreaConsola.append("\tAvion en mantenimiento: " + ((contadorAviones > 2)?("Avion " + (contadorAviones-2)+": -Ocupado"):"Ninguno: -Disponible") +"\n");
        txtAreaConsola.append("\tTurnos restantes" + contadorTurnosMantenimiento + "\n");
        for (int i = 2; i <= getCantidadEstaciones(); i++) {
            txtAreaConsola.append("Estacion " + i +"\n");            
            txtAreaConsola.append("\tAvion en mantenimiento: " + ("Ninguno: -Disponible") +"\n");
            txtAreaConsola.append("\tTurnos restantes"  + "\n");            
        }
        txtAreaConsola.append("------------------------------" + "\n");
        txtAreaConsola.append("Cantidad de maletas en sistema: " + contadorEquipaje + "\n");
        txtAreaConsola.append("\n \n \n");
        //((contadorAviones>2)?listaAvionesNombre.removerDelFrente():null);
    }

    public void graficarColaDesabordaje(){
        String nombre;
        Grafica grafica;
        File file;
        
        nombre = "imagenListaUno";
        grafica = new Grafica();
        
        try 
        {
            grafica.graficar(colaDesabordaje.primero, nombre);
            file = new File(nombre + ".jpg");
            //Desktop.getDesktop().open(file);
            
            ImageIcon imagen = new ImageIcon("imagenListaUno.jpg");
            Image i = imagen.getImage();
            desabordajes = new ImageIcon(i.getScaledInstance(600, 45, Image.SCALE_SMOOTH));        
            lbDesabordaje.setIcon(desabordajes);
        } 
        catch (IOException ex) {
            //Logger.getLogger(Lista.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void graficarListaAviones(){
        String nombre;
        Grafica grafica;
        File file;
        
        nombre = "imagenListaDos";
        grafica = new Grafica();
        
        try 
        {
            grafica.graficar(listaAviones.primero, nombre);
            file = new File(nombre + ".jpg");
            //Desktop.getDesktop().open(file);
            ImageIcon imagen = new ImageIcon("imagenListaDos.jpg");
            Image i = imagen.getImage();
            aviones = new ImageIcon(i.getScaledInstance(600, 60, Image.SCALE_SMOOTH));        
            lbAviones.setIcon(aviones);
        } 
        catch (IOException ex) {
            Logger.getLogger(Lista.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void graficarListaEquipaje(){
        String nombre;
        GraficaCircular grafica;
        File file;
        
        nombre = "imagenListaTres";
        grafica = new GraficaCircular();
        
        try 
        {
            grafica.graficar(listaEquipaje.primero, nombre);
            file = new File(nombre + ".jpg");
            //Desktop.getDesktop().open(file);
            ImageIcon imagen = new ImageIcon("imagenListaTres.jpg");
            Image i = imagen.getImage();
            equipaje = new ImageIcon(i.getScaledInstance(600, 52, Image.SCALE_SMOOTH));        
            lbEquipaje.setIcon(equipaje);
        } 
        catch (IOException ex) {
            Logger.getLogger(Lista.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void graficarListaEscritorios(){
        String nombre;
        Grafica grafica;
        File file;
        
        nombre = "imagenListaCuatro";
        grafica = new Grafica();
        
        try 
        {
            grafica.graficar(listaEscritorios.primero, nombre);
            file = new File(nombre + ".jpg");
            //Desktop.getDesktop().open(file);
            ImageIcon imagen = new ImageIcon("imagenListaCuatro.jpg");
            Image i = imagen.getImage();
            escritorios = new ImageIcon(i.getScaledInstance(600, 45, Image.SCALE_SMOOTH));        
            lbRegistro.setIcon(escritorios);
        } 
        catch (IOException ex) {
            Logger.getLogger(Lista.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void graficarListaEstaciones(){
        String nombre;
        Grafica grafica;
        File file;
        
        nombre = "imagenListaCinco";
        grafica = new Grafica();
        
        try 
        {
            grafica.graficar(listaEstaciones.primero, nombre);
            file = new File(nombre + ".jpg");
            //Desktop.getDesktop().open(file);
            ImageIcon imagen = new ImageIcon("imagenListaCinco.jpg");
            Image i = imagen.getImage();
            estaciones = new ImageIcon(i.getScaledInstance(600, 50, Image.SCALE_SMOOTH));        
            lbEstaciones.setIcon(estaciones);
        } 
        catch (IOException ex) {
            Logger.getLogger(Lista.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void graficarPilaDocumentos(){
        String nombre;
        Grafica grafica;
        File file;
        
        nombre = "imagenListaSeis";
        grafica = new Grafica();
        
        try 
        {
            grafica.graficar(pilaDocumentos.primero, nombre);
            file = new File(nombre + ".jpg");
            //Desktop.getDesktop().open(file);
            ImageIcon imagen = new ImageIcon("imagenListaSeis.jpg");
            Image i = imagen.getImage();
            documentos = new ImageIcon(i.getScaledInstance(600, 45, Image.SCALE_SMOOTH));        
            lbDocumentos.setIcon(documentos);
        } 
        catch (IOException ex) {
            Logger.getLogger(Lista.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btAutomatico;
    private javax.swing.JButton btSalir;
    private javax.swing.JButton btSiguiente;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lbAviones;
    private javax.swing.JLabel lbDesabordaje;
    private javax.swing.JLabel lbDocumentos;
    private javax.swing.JLabel lbEquipaje;
    private javax.swing.JLabel lbEstaciones;
    private javax.swing.JLabel lbRegistro;
    private javax.swing.JPanel pnFondo;
    public javax.swing.JTextArea txtAreaConsola;
    // End of variables declaration//GEN-END:variables
}
