package proyecto2;

import java.util.Random;

public class Pasajero {
    protected int cantidadMaletas;
    protected int cantidadDocumentos;
    protected int turnoRegistro;
    protected String Nombre;
    
    public Pasajero(){
        generarAletorio();
    }

    public int getCantidadMaletas() {
        return cantidadMaletas;
    }

    public void setCantidadMaletas(int cantidadMaletas) {
        this.cantidadMaletas = cantidadMaletas;
    }

    public int getCantidadDocumentos() {
        return cantidadDocumentos;
    }

    public void setCantidadDocumentos(int cantidadDocumentos) {
        this.cantidadDocumentos = cantidadDocumentos;
    }

    public int getTurnoRegistro() {
        return turnoRegistro;
    }

    public void setTurnoRegistro(int turnoRegistro) {
        this.turnoRegistro = turnoRegistro;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }
    
    public void generarAletorio(){
        Random numero = new Random();
        cantidadMaletas = numero.nextInt(4)+2;
        cantidadDocumentos = numero.nextInt(10)+1;
        turnoRegistro = numero.nextInt(3)+1;
    }
}
