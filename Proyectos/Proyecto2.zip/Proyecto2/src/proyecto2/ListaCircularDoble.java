package proyecto2;

public class ListaCircularDoble extends Lista{
    public ListaCircularDoble(){
        this("MiListaCircularDoble");
    }
    public ListaCircularDoble(String nombre){
        this.nombre=nombre; primero = ultimo= null;
    }
    
    public void insertarAlFrente(Object dato){
        try{
        //CREANDO NODO
        Nodo nuevo = new Nodo(dato);
        if(estaVacia()){    
            //APUNTANDO ENLACES
            nuevo.setAnterior(ultimo);
            nuevo.setSiguiente(primero);
            //VERIFICANDO PRIMERO Y ULTIMO
            primero = nuevo;
            ultimo = nuevo;
        }else{
            primero.setAnterior(nuevo);
            nuevo.setSiguiente(primero);
            ultimo.setSiguiente(nuevo);
            nuevo.setAnterior(ultimo);
            primero = nuevo;
        }}catch(NullPointerException ex){}
    }
    
    public void insertarAlFinal(Object dato){
        try{
        if (estaVacia()){
            primero = ultimo = new Nodo(dato);
            //APUNTANDO ENLACES
            ultimo.setAnterior(ultimo);
            ultimo.setSiguiente(ultimo);
        }else{
            //CREANDO NODO
            Nodo nuevo = new Nodo(dato);
            //CAMBIANDO ENLACES
            ultimo.setSiguiente(nuevo);
            nuevo.setAnterior(ultimo);
            nuevo.setSiguiente(primero);
            primero.setAnterior(nuevo);
            //VERIFICANDO ULTIMO Y PRIMERO
            ultimo = nuevo;
        }}catch(NullPointerException ex){}
    }
    
    public void removerDelFrente(){
        try{
        if (estaVacia()){
            System.out.println("Lista Vacia");
        }
        else if(primero == ultimo){
            primero = ultimo = null;
        }
        else{
            //NodoCircularDoble temporal = primero.getSiguiente();
            primero = primero.getSiguiente();
            ultimo.setSiguiente(primero);
            primero.setAnterior(ultimo); 
            //primero = temporal;
        }}catch(NullPointerException ex){}
    }
    
    public void removerDelFinal(){
        try{
        if(estaVacia()){
            System.out.println("Lista Vacia");
        }
        else if (primero == ultimo) {
            primero = ultimo = null;
        }
        else{
            //ASIGNANDO NODO TEMPORAL
            Nodo temporal = primero;
            do{
                //CUANDO ENCUENTRA AL ULTIMO NODO
                if(temporal.getSiguiente() == ultimo){
                    //MOVIENDO ENLACES
                    temporal.setSiguiente(primero);
                    primero.setAnterior(temporal);
                    //ASIGNANDO TEMPORAL A ULTIMO
                    ultimo = temporal;
                }
                temporal = temporal.getSiguiente();
            }while(temporal != primero);
        }}catch(NullPointerException ex){}
    }
    public void imprimir(){
        try{
        if(estaVacia()){
            System.out.println("La lista esta vacia");
        }else{
            Nodo actual = primero;
            do{
                System.out.println("Dato: " + actual.getDato());
                actual = actual.getSiguiente();
            }while(actual != primero);
        }}catch(NullPointerException ex){}    
    }
}