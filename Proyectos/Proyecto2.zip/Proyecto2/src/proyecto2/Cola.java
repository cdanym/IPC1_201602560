package proyecto2;
/**
 * @author dmonterroso
 */
public class Cola extends ListaEnlazadaSimple{
    
    public Cola(){
        super();
    }
    public void encolar(Object dato){
        try{
        insertarAlFinal(dato);
        }catch(NullPointerException ex){}
    }
    public void descolar(){
        try{
        removerDelFrente();
        }catch(NullPointerException ex){}
    }
}
