package proyecto2;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;

/**
 *
 * @author dmonterroso
 */
public abstract class Lista{
    public String nombre;
    public Nodo primero, ultimo;
    public Boolean estaVacia(){
        return primero==null && ultimo==null;
    }
    //@Override
    public String getNombre(){
        return nombre;
    }
    public abstract void insertarAlFrente(Object dato);
    public abstract void insertarAlFinal(Object dato);
    public abstract void removerDelFrente();
    public abstract void removerDelFinal();
    public abstract void imprimir();
    
    public void graficarListaAviones(){
        String nombre;
        Grafica grafica;
        File file;
        
        nombre = "imagenLista";
        grafica = new Grafica();
        
        try 
        {
            grafica.graficar(ultimo, nombre);
            file = new File(nombre + ".jpg");
            Desktop.getDesktop().open(file);
        } 
        catch (IOException ex) {
            //Logger.getLogger(Lista.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}