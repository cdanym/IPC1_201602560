package proyecto2;

import java.awt.Desktop;
import java.io.File;
import java.io.IOException;

/**
 *
 * @author Anthony Chan
 */
public class ListaEnlazadaDoble extends Lista{
    public ListaEnlazadaDoble(){ this("MiListaEnlazadaDoble");}
    public ListaEnlazadaDoble(String nombre){this.nombre = nombre; primero = ultimo = null;}
    
    public void agregarFinal(Object dato){
        try{
        if(estaVacia()){
            primero = ultimo = new Nodo(dato);
        }
        else{
            Nodo nuevo = new Nodo(dato);
            ultimo.setSiguiente(nuevo);
            nuevo.setAnterior(ultimo);
            ultimo = nuevo;
        }}catch(NullPointerException ex){}
    }
    
    public void insertarAlFrente(Object dato){
        try{
        if(estaVacia()){
            //SE CREA EL NODO
            Nodo nuevo = new Nodo(dato);
            //COMO NO HAY NADA EN LA LISTA, SE ASIGNA EL NUEVO NODO A PRIMERO Y ULTIMO
            primero = nuevo;
            ultimo = nuevo;
        }
        else{
            //1. COMO HAY UN NODO O MAS EN LA LISTA SE CREA EL NODO
            Nodo nuevo = new Nodo(dato);
            //2. SE MUEVEN LOS ENLACES
            nuevo.setSiguiente(primero);
            primero.setAnterior(nuevo);
            //3. SE VERIFICA PRIMERO Y ULTIMO
            primero = nuevo;
        }}catch(NullPointerException ex){}
    }
    
    public void insertarAlFinal(Object dato){
        try{
        if(estaVacia()){
            //No hay nada
            //System.out.println("Lista vacia");
            Nodo nuevo = new Nodo(dato);
            primero = nuevo;
            ultimo = nuevo;
        }else{
            Nodo temporal = primero;
            while(temporal != null){
                //System.out.println("dato: " + temporal.getDato());
                //SI EL SIGUIEN ES EL ULTIMO ENTONCES TEMPORAL ES EL ANTEPENULTIMO
                if (temporal.getSiguiente()==ultimo) {
                    //1. CREANDO EL NUEVO NODO
                    Nodo nuevo = new Nodo(dato);
                    //2. MOVIENDO ENLACES
                    temporal.setSiguiente(nuevo);
                    nuevo.setAnterior(temporal);
                    temporal.setSiguiente(ultimo);
                    ultimo.setAnterior(nuevo);
                    System.out.println("agregado"+nuevo.getDato());
                    //3. PRIMERO SIGUE SIENDO PRIMERO Y ULTIMO SIGUE SIENDO ULTIMO
                }
                temporal = temporal.getSiguiente();
            }
        }}catch(NullPointerException ex){}
    }
    
    public void removerDelFinal(){
        try{
        if(estaVacia()){
            //No hay nada
            System.out.println("Lista vacia");
        }else{
            Nodo temporal = primero;
            while(temporal != null){
                //System.out.println("dato: " + temporal.getDato());
                //SI EL SIGUIEN ES EL ULTIMO ENTONCES TEMPORAL ES EL ANTEPENULTIMO
                if (temporal.getSiguiente()==ultimo) {
                    //1. MOVER ENLACES, QUITANDO LA REFERENCIA AL ELEMENTO QUE QUEREMOS QUITAR (DEJANDO SOLO AL QUE SE VA A ELIMINAR)
                    temporal.setSiguiente(null);
                    // 2. VERIFICAR ULTIMO Y PRIMERO
                    ultimo = temporal;
                    break;
                }
                // RECORRIENDO LA LISTA
                temporal = temporal.getSiguiente();
            }
        }}catch(NullPointerException ex){}
    }
    
    public void removerDelFrente(){
        try{
        if(estaVacia()){
            System.out.println("Lista Vacia");
        }else{
            
            Nodo segundo = primero.getSiguiente();
            //1. MOVER LOS ENLACES (QUITANDOLOS HACIA EL ELEMENTO QUE VOY A ELIMINAR
            segundo.setAnterior(null);
            // 2. VERIFICAR PRIMERO Y ULTIMO
            primero = segundo;
            
        }}catch(NullPointerException ex){}
    }
    
    public void imprimir(){
        try{
        if(estaVacia()){
            System.out.println("Lista Vacia");
        }else{
            Nodo actual = primero;
            while(actual != null){
                System.out.println("Dato: " + actual.getDato());
                actual = actual.getSiguiente();
            }
        }}catch(NullPointerException ex){}
    }
}

