package proyecto2;

/**
 *
 * @author dmonterroso
 */
public class ListaEnlazadaSimple extends Lista{
    public ListaEnlazadaSimple(){ this( "miListaEnlazadaSimple" ); }
    public ListaEnlazadaSimple(String nombre){ this.nombre = nombre; primero =  ultimo = null; }
    
    @Override
    public void insertarAlFrente(Object dato){
        try{
        if(estaVacia()){
            primero = ultimo = new Nodo(dato);
        }else{
            //primero = new Nodo(dato,primero);
            Nodo nuevo = new Nodo(dato);
            nuevo.setSiguiente(primero);
            primero = nuevo;
        }}catch(NullPointerException ex){}
    }
    
    public void insertarAlFinal(Object dato){
        try{
        if(estaVacia()){
            primero = ultimo = new Nodo(dato);
        }else{
            Nodo nuevo = new Nodo(dato);
            ultimo.setSiguiente(nuevo);
            ultimo = nuevo;
        }}catch(NullPointerException ex){}
    }
    
    public void removerDelFrente(){
        try{
        if(estaVacia()){
            System.out.println("Lista Vacia");
        }else{
            Nodo segundo = primero.getSiguiente();
            primero = segundo;
        }}catch(NullPointerException ex){}
    }
    
    public void removerDelFinal(){
        try{
        if (estaVacia()) {
            System.out.println("Lista Vacia");
        }else{
            Nodo actual = primero;
            while (actual != null) {
                if(actual.getSiguiente() == ultimo){
                    actual.setSiguiente(null);
                    ultimo = actual;
                    break;
                }
                actual = actual.getSiguiente();
            }
        }}catch(NullPointerException ex){}
    }
    
    public void imprimir(){
        try{
        Nodo temporal = primero;
        String cadena;
        //cadena = new String( "contenido: \n" );
        if(null == temporal){ System.out.println("contenido: {vacia}");
        }else{
            while( temporal != null ){
                 System.out.println("---" + temporal.getDato());
                 temporal = temporal.getSiguiente();
            }
        }}catch(NullPointerException ex){}
    }
}
