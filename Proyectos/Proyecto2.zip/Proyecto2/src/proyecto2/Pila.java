package proyecto2;
/**
 *
 * @author dmonterroso
 */
public class Pila extends ListaEnlazadaSimple {
    public Pila(){
        super();
    }
    public void apilar(Object dato){
        try{
        insertarAlFrente(dato);
        }catch(NullPointerException ex){}
    }
    public void desapilar(){
        try{
        removerDelFrente();
        }catch(NullPointerException ex){}
    }
}
