package proyecto2;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
/**
 *
 * @author dmonterroso
 */
public class Grafica {
    
    File file;
    FileWriter fileWriter;
    BufferedWriter bufferedWriter;
    PrintWriter printWriter;
    int indice;
    
    private final String DOT_PATH = "C:\\Program Files (x86)\\Graphviz2.38\\bin\\dot.exe";
    private final String TPARAM = "-Tjpg";
    private final String TOPARAM = "-o";
    
    public Grafica(){}
    
    public void graficar(Nodo temporal, String nombre)throws IOException{
        String fileIn;
        String fileOut;
        
        fileIn = nombre+".txt";
        fileOut = nombre+".jpg";
        
        file = new File(fileIn);
        fileWriter = new FileWriter(file);
        bufferedWriter = new BufferedWriter(fileWriter);
        printWriter = new PrintWriter(bufferedWriter);
        

        printWriter.println("digraph G {");
        printWriter.println("rankdir=LR;");
        printWriter.println("node [shape=record];");
        
        indice = 0;
        declararNodo(temporal);
        
        indice = 0;
        enlazarNodo(temporal, 0);
        
        printWriter.println("}");

        //**
        printWriter.close();
        bufferedWriter.close();
        
        
        String [] cmd = {DOT_PATH, TPARAM, fileIn, TOPARAM, fileOut};
        Runtime rt = Runtime.getRuntime();
        rt.exec(cmd);
    }
    
    public void declararNodo(Nodo temporal){
        if(temporal != null)
        {
             
            printWriter.println("node"+indice+"[label = " +"\"{<val>VALOR["+ temporal.getDato() + "]|<ptr> siguiente}\""+ "];");
            indice++;
            if(temporal.getSiguiente() != null)
                declararNodo(temporal.getSiguiente());
                
        }
    }
    
    public void enlazarNodo(Nodo temporal, int actual){
        if(temporal != null)
        {
            if(temporal.getSiguiente() != null)
            {   
                indice++;
                printWriter.println("\"node" + actual + "\":ptr->" + "\"node" + indice+ "\"");
                enlazarNodo(temporal.getSiguiente(),indice);
            }
        }
    }
}



class GraficaCircular{

    File file;
    FileWriter fileWriter;
    BufferedWriter bufferedWriter;
    PrintWriter printWriter;
    int indice;
    
    Nodo primer;
    
    private final String DOT_PATH = "C:\\Program Files (x86)\\Graphviz2.38\\bin\\dot.exe";
    private final String TPARAM = "-Tjpg";
    private final String TOPARAM = "-o";
    
    public GraficaCircular(){}
    
    public void graficar(Nodo temporal, String nombre)throws IOException{
        String fileIn;
        String fileOut;
        
        fileIn = nombre+".txt";
        fileOut = nombre+".jpg";
        
        file = new File(fileIn);
        fileWriter = new FileWriter(file);
        bufferedWriter = new BufferedWriter(fileWriter);
        printWriter = new PrintWriter(bufferedWriter);
        

        printWriter.println("digraph G {");
        printWriter.println("rankdir=LR;");
        printWriter.println("node [shape=record];");
        
        indice = 0;
        primer = temporal;
        declararNodo(temporal);
        
        indice = 0;
        
        enlazarNodo(temporal, 0);
        
        printWriter.println("}");

        //**
        printWriter.close();
        bufferedWriter.close();
        
        
        String [] cmd = {DOT_PATH, TPARAM, fileIn, TOPARAM, fileOut};
        Runtime rt = Runtime.getRuntime();
        rt.exec(cmd);
    }
     
    //Nodo primer;
    public void declararNodo(Nodo temporal){
       
        if(temporal != primer.getAnterior())
        {
             
            printWriter.println("node"+indice+"[label = " +"\"{<val>VALOR["+ temporal.getDato() + "]|<ptr> siguiente}\""+ "];");
            indice++;
            if(temporal.getSiguiente() != primer)
                declararNodo(temporal.getSiguiente());
                
        }
    }
    
    public void enlazarNodo(Nodo temporal, int actual){
        //Nodo primer = temporal;
        if(temporal != primer.getAnterior())
        {
            if(temporal.getSiguiente() != primer)
            {   
                indice++;
                printWriter.println("\"node" + actual + "\":ptr->" + "\"node" + indice+ "\"");
                enlazarNodo(temporal.getSiguiente(),indice);
            }
        }
    }

}
