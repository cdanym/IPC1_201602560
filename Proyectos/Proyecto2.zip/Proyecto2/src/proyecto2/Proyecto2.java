package proyecto2;
/**
 *
 * @author dmonterroso
 */
public class Proyecto2 {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Lista listaCD = new ListaCircularDoble();
        
        listaCD.insertarAlFrente(10);
        listaCD.insertarAlFrente(20);
        listaCD.insertarAlFrente(30);
        listaCD.insertarAlFrente(40);
        listaCD.imprimir(); //NO PUEDE IMPRIMIR VACIO
        System.out.println("----------");
        listaCD.removerDelFrente();
        listaCD.removerDelFrente();
        listaCD.removerDelFrente();
        listaCD.removerDelFinal();
        listaCD.imprimir();
        
        Inicio inicio = new Inicio();
    }
    
}
