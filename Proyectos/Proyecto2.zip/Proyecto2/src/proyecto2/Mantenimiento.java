package proyecto2;
/**
 *
 * @author dmonterroso
 */
public class Mantenimiento {
    protected String nombre;
    protected String avionNombre;
    protected int turnoRestante;
    protected boolean estado;
    
    public Mantenimiento(){
        this.turnoRestante = 0;
        this.estado = false;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getAvionNombre() {
        return avionNombre;
    }

    public void setAvionNombre(String avionNombre) {
        this.avionNombre = avionNombre;
    }

    public int getTurnoRestante() {
        return turnoRestante;
    }

    public void setTurnoRestante(int turnoRestante) {
        this.turnoRestante = turnoRestante;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }
    
}
