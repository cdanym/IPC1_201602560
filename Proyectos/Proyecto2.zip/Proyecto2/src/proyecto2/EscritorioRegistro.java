package proyecto2;
/**
 *
 * @author dmonterroso
 */
public class EscritorioRegistro {
    protected String nombre;
    protected String clienteAtendido;
    protected boolean estado;
    protected int cantDocReg;
    protected int turnoRestante;
    protected Pasajero pasajero;

    public EscritorioRegistro() {
        this.clienteAtendido = "";
        this.cantDocReg = 0;
        this.turnoRestante = 0;
        this.estado = false;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(int cantidad) {
        switch(cantidad){
            case 1: nombre = "A"; break;
            case 2: nombre = "B"; break;
            case 3: nombre = "C"; break;
            case 4: nombre = "D"; break;
            case 5: nombre = "E"; break;
            case 6: nombre = "F"; break;
            case 7: nombre = "G"; break;
            case 8: nombre = "H"; break;
            case 9: nombre = "I"; break;
            case 10: nombre = "J"; break;
            case 11: nombre = "K"; break;
            case 12: nombre = "L"; break;
            case 13: nombre = "M"; break;
            case 14: nombre = "N"; break;
            case 15: nombre = "O"; break;
            case 16: nombre = "P"; break;
            case 17: nombre = "Q"; break;
            case 18: nombre = "R"; break;
            case 19: nombre = "S"; break;
            case 20: nombre = "T"; break;
            case 21: nombre = "U"; break;
            case 22: nombre = "V"; break;
            case 23: nombre = "W"; break;
            case 24: nombre = "X"; break;
            case 25: nombre = "Y"; break;
            case 26: nombre = "Z"; break;
        }
    }

    public String getClienteAtendido() {
        return clienteAtendido;
    }

    public void setClienteAtendido(String clienteAtendido) {
        this.clienteAtendido = clienteAtendido;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }

    public int getCantDocReg() {
        return cantDocReg;
    }

    public void setCantDocReg(int cantDocReg) {
        this.cantDocReg = cantDocReg;
    }

    public int getTurnoRestante() {
        return turnoRestante;
    }

    public void setTurnoRestante(int turnoRestante) {
        this.turnoRestante = turnoRestante;
    }

}