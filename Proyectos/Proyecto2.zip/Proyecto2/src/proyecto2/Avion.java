package proyecto2;

import java.util.Random;
/**
 *
 * @author dmonterroso
 */
public class Avion extends Cola{
    protected String nombre;
    protected int tipo;
    protected int pasajeros;
    protected int turnoDesabordaje;
    protected int turnoMantenimiento;

    public Avion() {
        generarAleatorio();
    }

    public String getNombre(){
        return nombre;
    }
    
    public void setNombre(String nombre){
        this.nombre = nombre;
    }
    
    public String getTipo() {
        //return tipo;
        switch(this.tipo){
            case 1: return "---Pequeño---";
            case 2: return "---Mediano---";
            case 3: return "---Grande---";
        }
        return null;
    }

    public void setTipo(int tipo) {
        this.tipo = tipo;
    }

    public int getPasajeros() {
        return pasajeros;
    }

    public void setPasajeros(int pasajeros) {
        this.pasajeros = pasajeros;
    }

    public int getTurnoDesabordaje() {
        return turnoDesabordaje;
    }

    public void setTurnoDesabordaje(int turnoDesabordaje) {
        this.turnoDesabordaje = turnoDesabordaje;
    }

    public int getTurnoMantenimiento() {
        return turnoMantenimiento;
    }

    public void setTurnoMantenimiento(int turnoMantenimiento) {
        this.turnoMantenimiento = turnoMantenimiento;
    }
    
    public void generarAleatorio(){
        Random numero = new Random();
        tipo = numero.nextInt(3)+1; //NUMEROS ALEATORIOS ENTRE 1 Y 6 
        switch(tipo){
            case 1: pasajeros = (int)Math.floor(Math.random()*(10-5+1)+(5)); 
                    turnoDesabordaje=tipo;
                    turnoMantenimiento=(int)Math.floor(Math.random()*(3-1+1)+(1));
                    break;
            case 2: pasajeros = (int)Math.floor(Math.random()*(25-15+1)+(15)); 
                    turnoDesabordaje=tipo;
                    turnoMantenimiento=(int)Math.floor(Math.random()*(4-2+1)+(2));
                    break;
            case 3: pasajeros = (int)Math.floor(Math.random()*(40-30+1)+(30)); 
                    turnoDesabordaje=tipo;
                    turnoMantenimiento=(int)Math.floor(Math.random()*(6-3+1)+(3));
                    break;
        }
    }
    
}
