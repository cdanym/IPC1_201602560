package practica1;
import java.util.Random;
import java.util.Scanner;
/**
 *
 * @author dmonterroso
 */
public class Practica1 {
        public static final int columnas = 70;
        public static final int filas = 35;
        public static String Nombre, fechaNac;
        public static char [][] mapaMatriz, auxMatriz;
        public static int juego, movimientos, puntos = 10;
        public static boolean ciclo = true;
        public static boolean mostrarMenu = true;
        public static String historial;
        
    public static void main(String[] args) {
        //Mapa mapa = new Mapa(mapaAncho,mapaAlto);
        historial = "N°\t Nombre\t Fecha Nac\t Punteo\t Movimientos\n";
        mapaMatriz = new char [filas][columnas];
        auxMatriz = new char [filas][columnas];
        menu();
    }
    
    public static void menu(){
        while (mostrarMenu = true){
            System.out.println("1. Iniciar Juego \n2. Regresar al juego \n3. Historial \n4. Salir \nIngrese una opcion...");
            int opcion;
            Scanner entrada = new Scanner(System.in);
            opcion = entrada.nextInt();
            switch (opcion){
                case 1:
                    System.out.println("Ingrese su nombre: ");
                    Scanner n = new Scanner(System.in);
                    Nombre = n.nextLine();
                    System.out.println("Ingrese su fecha de nacimiento: ");
                    Scanner f = new Scanner(System.in);
                    fechaNac = f.nextLine();
                    //System.out.println("Opcion 1, Hola " + Nombre + ", " + fechaNac + ".");   
                    iniciarMapa(); //Llenando la matriz
                    Frutos();
                    if(movimientos > 0){
                        juego ++;
                        guardarHistorial();
                        puntos = 10;
                        movimientos = 0;
                    }
                    ciclo = true;
                    mostrarMenu = false;
                    puntos = 10;
                    movimientos = 0;
                    datos(Nombre,puntos,movimientos);
                    imprimirMapa(); //Imprimiendo la matriz
                    movimientos();
                    break;
                case 2:
                    if (movimientos > 0) {
                        //System.out.println("Opcion 2 - Regresar al juego");
                        ciclo = true;
                        mostrarMenu = false;
                        datos(Nombre,puntos,movimientos);
                        imprimirMapa();
                        movimientos();
                    }
                    else
                        System.out.println("No hay juego en pausa...\n");
                    break;
                case 3:
                    System.out.println("Historial");
                    System.out.println(historial + "\n");
                    break;
                case 4: 
                    System.exit(0);
                default: 
                    System.out.println("Opcion no valida"); 
          
            }
        }   
    }
    
    public static void datos(String n, int p, int m){
        System.out.println("Nombre: " + n);
        System.out.println("Puntos: " + p);
        System.out.println("Movimientos: " + m);
    } 
    
    //LLENANDO LA MATRIZ DE ESPACIOS Y #
    public static void iniciarMapa(){
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                mapaMatriz[i][j] = ' ';
                if (i == 0 || i == 34){
                    mapaMatriz[i][j] = '#';
                    //System.out.print(this.mapaMatriz[i][j]);
                }
                if (j == 0) {
                    mapaMatriz[i][0] = '#';
                    //System.out.print(this.mapaMatriz[i][0]);
                }
                if (j == 69){
                    mapaMatriz[i][69] = '#';
                    //System.out.print(this.mapaMatriz[i][69]);
                }
                if ( i == 3 && j == 3){
                    mapaMatriz[i][j] = '@';
                }
                //auxMatriz = mapaMatriz;
            }
        }
    }
    //IMPRIMIR EL MAPA DE 70x35
    public static void imprimirMapa(){
        for (int i = 0; i < filas; i++) {
            for (int j = 0; j < columnas; j++) {
                System.out.print(mapaMatriz[i][j]);
            }
            System.out.println();
        }
    }
    
    public static void Frutos(){
        //int numero = (int)(Math.random()*3+1); //Numeros aleatorios entre 1 y 3
        for (int porcentaje = 0; porcentaje < 40; porcentaje++) {
            Random comida1 = new Random();
            int x = comida1.nextInt(35);
            int y = comida1.nextInt(70);
            while (mapaMatriz[x][y] != ' '){
                x = comida1.nextInt(35);
                y = comida1.nextInt(70);
            }
            mapaMatriz[x][y] = '%';
        }
        for (int dolar = 0; dolar < 30; dolar++) {
            Random comida2 = new Random();
            int x = comida2.nextInt(35);
            int y = comida2.nextInt(70);
            while (mapaMatriz[x][y] != ' '){
                x = comida2.nextInt(35);
                y = comida2.nextInt(70);
            }
            mapaMatriz[x][y] = '$';
        }
        for (int numeral = 0; numeral < 20; numeral++) {
            Random comida3 = new Random();
            int x = comida3.nextInt(35);
            int y = comida3.nextInt(70);
            while (mapaMatriz[x][y] != ' '){
                x = comida3.nextInt(35);
                y = comida3.nextInt(70);
            }
            mapaMatriz[x][y] = '#';
        }  
    }
    
    public static void movimientos(){
        Scanner entrada = new Scanner(System.in);
        String letra;
        int posX1 = 0, posY1 = 0;
        while (ciclo == true){
            switch(puntos){
                case 0:
                    ciclo = false;
                    mostrarMenu = true;
                    System.out.println("Juego Perdido");
                    juego ++;
                    guardarHistorial();
                    puntos = 10;
                    movimientos = 0;
                    menu();
                    break;
                case 100:
                    ciclo = false;
                    mostrarMenu = true;
                    System.out.println("Juego Ganado");
                    juego ++;
                    guardarHistorial();
                    puntos = 10;
                    movimientos = 0;
                    menu();
                    break;
                default:
                    System.out.println("Elija una letra...");
                    letra = entrada.nextLine();
                    if("w".equalsIgnoreCase(letra)){
                        for (int i = 0; i < filas; i++) {
                            for (int j = 0; j < columnas; j++) {
                                if (mapaMatriz[i][j] == '@') {
                                    posX1 = j; //Posición en X
                                    posY1 = i; //Posición en Y
                                }
                            }
                        }
                        posY1 --;
                        if (mapaMatriz[posY1][posX1] != '#' ){
                            if(mapaMatriz[posY1][posX1] == ' '){ //AVANZAR
                                mapaMatriz[posY1][posX1] = '@';
                                posY1 ++;
                                mapaMatriz[posY1][posX1] = ' ';
                             }
                            if(mapaMatriz[posY1][posX1] == '%'){ //AVANZAR Y AUMENTAR 10 PTS.
                                mapaMatriz[posY1][posX1] = '@';
                                posY1 ++;
                                mapaMatriz[posY1][posX1] = ' ';
                                puntos = puntos + 10;
                            }
                            if(mapaMatriz[posY1][posX1] == '$'){ //AVANZAR Y DISMINUIR 10 PTS.
                                mapaMatriz[posY1][posX1] = '@';
                                posY1 ++;
                                mapaMatriz[posY1][posX1] = ' ';
                                puntos = puntos - 10;
                            }
                            movimientos ++;
                        }
                        datos(Nombre,puntos,movimientos);
                        imprimirMapa();
                    }
                    else if ("s".equalsIgnoreCase(letra)){
                        for (int i = 0; i < filas; i++) {
                            for (int j = 0; j < columnas; j++) {
                                if (mapaMatriz[i][j] == '@') {
                                    posX1 = j; //Posición en X
                                    posY1 = i; //Posición en Y
                                }
                            }
                        }
                        posY1 ++;
                        if (mapaMatriz[posY1][posX1] != '#' ){
                            if(mapaMatriz[posY1][posX1] == ' '){ //AVANZAR
                                mapaMatriz[posY1][posX1] = '@';
                                posY1 --;
                                mapaMatriz[posY1][posX1] = ' ';
                             }
                            if(mapaMatriz[posY1][posX1] == '%'){ //AVANZAR Y AUMENTAR 10 PTS.
                                mapaMatriz[posY1][posX1] = '@';
                                posY1 --;
                                mapaMatriz[posY1][posX1] = ' ';
                                puntos = puntos + 10;
                            }
                            if(mapaMatriz[posY1][posX1] == '$'){ //AVANZAR Y DISMINUIR 10 PTS.
                                mapaMatriz[posY1][posX1] = '@';
                                posY1 --;
                                mapaMatriz[posY1][posX1] = ' ';
                                puntos = puntos - 10;
                            }
                            movimientos ++;
                        }
                        datos(Nombre,puntos,movimientos);
                        imprimirMapa();
                    }
                    else if ("d".equalsIgnoreCase(letra)){
                        for (int i = 0; i < filas; i++) {
                            for (int j = 0; j < columnas; j++) {
                                if (mapaMatriz[i][j] == '@') {
                                    posX1 = j; //Posición en X
                                    posY1 = i; //Posición en Y
                                }
                            }
                        }
                        posX1 ++;
                        if (mapaMatriz[posY1][posX1] != '#' ){
                            if(mapaMatriz[posY1][posX1] == ' '){ //AVANZAR
                                mapaMatriz[posY1][posX1] = '@';
                                posX1 --;
                                mapaMatriz[posY1][posX1] = ' ';
                             }
                            if(mapaMatriz[posY1][posX1] == '%'){ //AVANZAR Y AUMENTAR 10 PTS.
                                mapaMatriz[posY1][posX1] = '@';
                                posX1 --;
                                mapaMatriz[posY1][posX1] = ' ';
                                puntos = puntos + 10;
                            }
                            if(mapaMatriz[posY1][posX1] == '$'){ //AVANZAR Y DISMINUIR 10 PTS.
                                mapaMatriz[posY1][posX1] = '@';
                                posX1 --;
                                mapaMatriz[posY1][posX1] = ' ';
                                puntos = puntos - 10;
                            }
                            movimientos ++;
                        }
                        datos(Nombre,puntos,movimientos);
                        imprimirMapa();
                    }
                    else if ("a".equalsIgnoreCase(letra)){
                        for (int i = 0; i < filas; i++) {
                            for (int j = 0; j < columnas; j++) {
                                if (mapaMatriz[i][j] == '@') {
                                    posX1 = j; //Posición en X
                                    posY1 = i; //Posición en Y
                                }
                            }
                        }
                        posX1 --;
                        if (mapaMatriz[posY1][posX1] != '#' ){
                            if(mapaMatriz[posY1][posX1] == ' '){ //AVANZAR
                                mapaMatriz[posY1][posX1] = '@';
                                posX1 ++;
                                mapaMatriz[posY1][posX1] = ' ';
                             }
                            if(mapaMatriz[posY1][posX1] == '%'){ //AVANZAR Y AUMENTAR 10 PTS.
                                mapaMatriz[posY1][posX1] = '@';
                                posX1 ++;
                                mapaMatriz[posY1][posX1] = ' ';
                                puntos = puntos + 10;
                            }
                            if(mapaMatriz[posY1][posX1] == '$'){ //AVANZAR Y DISMINUIR 10 PTS.
                                mapaMatriz[posY1][posX1] = '@';
                                posX1 ++;
                                mapaMatriz[posY1][posX1] = ' ';
                                puntos = puntos - 10;
                            }
                            movimientos ++;
                        }
                        datos(Nombre,puntos,movimientos);
                        imprimirMapa();
                    }
                    else if ("m".equalsIgnoreCase(letra)){
                        ciclo = false;
                        mostrarMenu = true;
                        System.out.println("Juego Pausado");
                        menu();
                    }
                    else{
                        System.out.println("Letra no valida");
                    }

            }        
        }    
    }
    
    public static void guardarHistorial(){
        historial = historial + (juego + "\t" + Nombre + "\t" + fechaNac + "\t" + puntos + "\t" + movimientos + "\n" );
    }
    
    
}
